<?php wp_head();?>
<p>Api</p>
<?php wp_footer();?>